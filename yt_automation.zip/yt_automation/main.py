# Entry point (will glue modules later)
print("Run scripts/generate_script.py to begin.")
